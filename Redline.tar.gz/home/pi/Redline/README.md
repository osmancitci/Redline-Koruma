BotProtect Update V2.0

Menggunakan script LineVodka dari MerKremont dan dicampur script LIN3-TCR dari alfathdirk

Cara install sama seperti BotKick / Line Vodka / LIN3-TCR
 

Bot akan langsung kick jika ada :
- Member nyalain/matiin QR Group
- Member Ngusir Member lain atau Calon Member Lain

Bot akan otomatis undang jika ada :
- Korban yang kena kick oleh member lain


Created by Farzain - zFz
